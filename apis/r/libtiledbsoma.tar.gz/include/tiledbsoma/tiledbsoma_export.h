
#ifndef TILEDBSOMA_EXPORT_H
#define TILEDBSOMA_EXPORT_H

#ifdef TILEDBSOMA_STATIC_DEFINE
#  define TILEDBSOMA_EXPORT
#  define TILEDBSOMA_NO_EXPORT
#else
#  ifndef TILEDBSOMA_EXPORT
#    ifdef TILEDB_SOMA_OBJECTS_EXPORTS
        /* We are building this library */
#      define TILEDBSOMA_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define TILEDBSOMA_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef TILEDBSOMA_NO_EXPORT
#    define TILEDBSOMA_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef TILEDBSOMA_DEPRECATED
#  define TILEDBSOMA_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef TILEDBSOMA_DEPRECATED_EXPORT
#  define TILEDBSOMA_DEPRECATED_EXPORT TILEDBSOMA_EXPORT TILEDBSOMA_DEPRECATED
#endif

#ifndef TILEDBSOMA_DEPRECATED_NO_EXPORT
#  define TILEDBSOMA_DEPRECATED_NO_EXPORT TILEDBSOMA_NO_EXPORT TILEDBSOMA_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef TILEDBSOMA_NO_DEPRECATED
#    define TILEDBSOMA_NO_DEPRECATED
#  endif
#endif

#endif /* TILEDBSOMA_EXPORT_H */
